import React, { useState } from 'react';
import {
  X,
  ExternalLink,
  Send,
  Bookmark,
  CheckCircle2,
  Clock,
  Sparkles,
  Building,
  MapPin,
  Calendar,
  DollarSign,
  FileText,
  ThumbsUp,
  ThumbsDown,
  ShieldCheck,
  Check,
  Mail,
  Copy,
  Briefcase,
  Share2,
  ListOrdered
} from 'lucide-react';
import { JobOpportunity, UserProfile, ApplicationStatus } from '../types';
import { generateJobPitch } from '../services/api';

interface JobDetailModalProps {
  job: JobOpportunity;
  profile: UserProfile;
  onClose: () => void;
  onUpdateStatus: (id: string, status: ApplicationStatus) => void;
  onToggleChecklist: (jobId: string, itemId: string) => void;
  onSendToTelegram: (job: JobOpportunity) => void;
  onFeedback: (job: JobOpportunity, sentiment: 'liked' | 'disliked', reason?: string) => void;
  telegramReady: boolean;
}

export const JobDetailModal: React.FC<JobDetailModalProps> = ({
  job,
  profile,
  onClose,
  onUpdateStatus,
  onToggleChecklist,
  onSendToTelegram,
  onFeedback,
  telegramReady,
}) => {
  const [activeTab, setActiveTab] = useState<'details' | 'pitch' | 'checklist'>('details');
  const [isGeneratingPitch, setIsGeneratingPitch] = useState(false);
  const [generatedPitch, setGeneratedPitch] = useState<string | null>(null);
  const [copiedPitch, setCopiedPitch] = useState(false);
  const [feedbackReason, setFeedbackReason] = useState('');
  const [showFeedbackInput, setShowFeedbackInput] = useState(false);

  const handleGeneratePitch = async () => {
    setIsGeneratingPitch(true);
    const res = await generateJobPitch(job, profile);
    setIsGeneratingPitch(false);
    if (res.ok && res.pitch) {
      setGeneratedPitch(res.pitch);
    }
  };

  const handleCopyPitch = () => {
    if (!generatedPitch) return;
    navigator.clipboard.writeText(generatedPitch);
    setCopiedPitch(true);
    setTimeout(() => setCopiedPitch(false), 2500);
  };

  const completedChecklistCount = job.checklist.filter((i) => i.completed).length;
  const isApplied = job.status === 'applied' || job.status === 'interview';
  const isSaved = job.status === 'saved' || job.status === 'preparing';

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="p-4 sm:p-6 bg-stone-900 text-stone-100 flex items-start justify-between gap-4 border-b border-stone-800">
          <div className="space-y-1.5 max-w-2xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-emerald-400 text-stone-950">
                {job.relevanceScore}% SPEC FIT
              </span>
              <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-white/10 text-emerald-300">
                {job.jobType}
              </span>
              <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-white/10 text-stone-300">
                {job.workType} · {job.location}
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-stone-800 text-stone-300">
                Source: {job.source}
              </span>
            </div>

            <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight">
              {job.title}
            </h2>

            <div className="text-xs text-stone-300 flex items-center gap-2">
              <span className="font-semibold text-white">{job.company}</span>
              <span>·</span>
              <span className="text-emerald-300 font-mono font-medium">{job.salaryStipend}</span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-stone-800 text-stone-400 hover:text-white hover:bg-stone-700 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Subnav */}
        <div className="px-4 sm:px-6 bg-stone-100 border-b border-stone-200 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 py-2">
            <button
              onClick={() => setActiveTab('details')}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
                activeTab === 'details'
                  ? 'bg-white text-stone-900 shadow-xs border border-stone-200'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Job Overview & Requirements
            </button>
            <button
              onClick={() => setActiveTab('pitch')}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'pitch'
                  ? 'bg-white text-stone-900 shadow-xs border border-stone-200'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              <span>Corporate PPA Kit & Cover Letter</span>
            </button>
            <button
              onClick={() => setActiveTab('checklist')}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'checklist'
                  ? 'bg-white text-stone-900 shadow-xs border border-stone-200'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <span>Application Checklist ({completedChecklistCount}/{job.checklist.length})</span>
            </button>
          </div>

          {/* Quick status selector */}
          <div className="hidden sm:flex items-center gap-1.5 py-2">
            <span className="text-stone-500 text-[11px]">Status:</span>
            <select
              value={job.status}
              onChange={(e) => onUpdateStatus(job.id, e.target.value as ApplicationStatus)}
              className="px-2 py-1 bg-white border border-stone-200 rounded text-stone-800 text-xs focus:outline-none"
            >
              <option value="new">New</option>
              <option value="saved">To Apply (Saved)</option>
              <option value="preparing">Preparing Materials</option>
              <option value="applied">Applied</option>
              <option value="interview">Interview</option>
              <option value="skipped">Skipped</option>
            </select>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-6 flex-1 text-xs">
          {activeTab === 'details' && (
            <div className="space-y-6">
              {/* Strategic Fit Box */}
              <div className="p-4 rounded-xl bg-emerald-50/70 border border-emerald-200 text-stone-800 space-y-2">
                <div className="flex items-center gap-2 text-emerald-950 font-bold text-sm">
                  <Sparkles className="w-4 h-4 text-emerald-600" />
                  <span>Why Your Profile Perfectly Qualifies:</span>
                </div>
                <p className="text-stone-700 leading-relaxed text-xs">
                  {job.whyAdefolabiFits}
                </p>
                <div className="pt-1 text-[11px] text-emerald-900 font-medium">
                  • Academic Degree: B.Sc. Political Science Education (LASU 3.57/5.0) satisfies criteria for governance, research, and analytical compliance.
                  <br />
                  • Federal Bidding Proof: 1 year at Kadaj Alliance LLC proves practical capability with RFQs, vendor matching, and federal compliance.
                </div>
              </div>

              {/* Compensation & Logistics Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3 bg-stone-50 border border-stone-200 rounded-lg">
                  <span className="text-[10px] text-stone-500 uppercase tracking-wide block font-semibold">Compensation / Allowance</span>
                  <span className="font-bold text-stone-900 text-xs sm:text-sm">{job.salaryStipend}</span>
                  <span className="text-[10px] text-emerald-700 block mt-0.5">Plus federal NYSC ₦77,000/mo allawee</span>
                </div>
                <div className="p-3 bg-stone-50 border border-stone-200 rounded-lg">
                  <span className="text-[10px] text-stone-500 uppercase tracking-wide block font-semibold">Application Deadline</span>
                  <span className="font-bold text-stone-900 text-xs sm:text-sm flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-amber-600" />
                    {job.deadline}
                  </span>
                  <span className="text-[10px] text-stone-500 block mt-0.5">Prior to or during camp placement</span>
                </div>
                <div className="p-3 bg-stone-50 border border-stone-200 rounded-lg">
                  <span className="text-[10px] text-stone-500 uppercase tracking-wide block font-semibold">Location & Commute</span>
                  <span className="font-bold text-stone-900 text-xs sm:text-sm">{job.location}</span>
                  <span className="text-[10px] text-stone-500 block mt-0.5">{job.notes}</span>
                </div>
              </div>

              {/* Requirements List */}
              <div className="space-y-2">
                <h4 className="font-bold text-stone-900 text-xs uppercase tracking-wider flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  Key Role Requirements
                </h4>
                <ul className="space-y-1.5 pl-2">
                  {job.requirements.map((req, i) => (
                    <li key={i} className="flex items-start gap-2 text-stone-700">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                      <span>{req}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Direct Outreach Contact */}
              {job.contactEmail && (
                <div className="p-3.5 bg-stone-50 border border-stone-200 rounded-xl flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-stone-500" />
                    <div>
                      <span className="font-medium text-stone-900 block">Direct Recruiter / HR Contact:</span>
                      <span className="font-mono text-emerald-700">{job.contactEmail}</span>
                    </div>
                  </div>
                  <a
                    href={`mailto:${job.contactEmail}?subject=Application for ${encodeURIComponent(job.title)} - NYSC Member Adefolabi Ladejobi`}
                    className="px-3 py-1.5 bg-white border border-stone-200 rounded-lg hover:bg-stone-100 font-medium text-[11px] text-stone-800 transition-colors"
                  >
                    Open in Mail Client
                  </a>
                </div>
              )}
            </div>
          )}

          {activeTab === 'pitch' && (
            <div className="space-y-4">
              {!generatedPitch ? (
                <div className="p-8 text-center bg-stone-50 rounded-xl border border-dashed border-stone-300 space-y-3">
                  <Sparkles className="w-8 h-8 text-emerald-600 mx-auto" />
                  <h3 className="font-bold text-stone-900 text-sm">
                    Generate Tailored PPA Request Letter & Cover Letter
                  </h3>
                  <p className="text-stone-600 max-w-md mx-auto text-xs leading-relaxed">
                    Our AI will draft:
                    <br />
                    1. <strong>Official Corporate PPA Request Letter</strong> for the Lagos State NYSC Coordinator / Camp Director
                    <br />
                    2. <strong>Cold Outreach Email</strong> to {job.company}'s HR / Talent Acquisition
                    <br />
                    3. <strong>Tailored Cover Letter</strong> emphasizing your Kadaj Alliance LLC US federal contracting experience.
                  </p>
                  <button
                    onClick={handleGeneratePitch}
                    disabled={isGeneratingPitch}
                    className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white rounded-xl font-semibold text-xs shadow-sm transition-all cursor-pointer flex items-center gap-2 mx-auto disabled:opacity-50"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>{isGeneratingPitch ? 'Drafting Official PPA Materials...' : 'Generate PPA Application Kit Now'}</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-stone-900">
                      Generated PPA Request Kit for {job.company}
                    </span>
                    <button
                      onClick={handleCopyPitch}
                      className="px-3 py-1.5 bg-stone-900 text-white rounded-lg text-xs font-medium hover:bg-stone-800 transition-colors flex items-center gap-1.5 cursor-pointer"
                    >
                      {copiedPitch ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedPitch ? 'Copied to Clipboard!' : 'Copy Entire Kit'}</span>
                    </button>
                  </div>

                  <div className="p-4 bg-stone-50 border border-stone-200 rounded-xl whitespace-pre-wrap font-sans text-xs text-stone-800 leading-relaxed max-h-[500px] overflow-y-auto">
                    {generatedPitch}
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'checklist' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-stone-900 text-xs uppercase tracking-wider">
                  Placement Action Items ({completedChecklistCount}/{job.checklist.length} Completed)
                </h4>
              </div>

              <div className="space-y-2">
                {job.checklist.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => onToggleChecklist(job.id, item.id)}
                    className={`p-3 rounded-lg border flex items-center gap-3 cursor-pointer transition-colors ${
                      item.completed
                        ? 'bg-emerald-50/70 border-emerald-200 text-stone-800'
                        : 'bg-white border-stone-200 hover:bg-stone-50 text-stone-700'
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded flex items-center justify-center shrink-0 ${
                        item.completed ? 'bg-emerald-600 text-white' : 'border border-stone-300 bg-white'
                      }`}
                    >
                      {item.completed && <Check className="w-3.5 h-3.5 stroke-3" />}
                    </div>
                    <span className={`text-xs ${item.completed ? 'line-through text-stone-500' : 'font-medium'}`}>
                      {item.label}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 sm:p-5 bg-stone-100 border-t border-stone-200 flex flex-wrap items-center justify-between gap-3 text-xs">
          {/* Feedback buttons */}
          <div className="flex items-center gap-2">
            <span className="text-stone-500 text-[11px]">Relevance:</span>
            <button
              onClick={() => onFeedback(job, 'liked', 'High relevance to federal procurement and NYSC')}
              className="p-1.5 rounded-md bg-white border border-stone-200 hover:bg-emerald-50 hover:text-emerald-700 transition-colors cursor-pointer"
              title="Train agent: highly relevant"
            >
              <ThumbsUp className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onFeedback(job, 'disliked', 'Not matching preference')}
              className="p-1.5 rounded-md bg-white border border-stone-200 hover:bg-red-50 hover:text-red-700 transition-colors cursor-pointer"
              title="Train agent: not relevant"
            >
              <ThumbsDown className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => onSendToTelegram(job)}
              className="px-3 py-2 rounded-xl bg-white border border-stone-300 text-stone-800 hover:bg-stone-50 font-medium text-xs flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Send className="w-3.5 h-3.5 text-emerald-600" />
              <span>Send Alert to Phone</span>
            </button>

            <a
              href={job.sourceUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-semibold text-xs flex items-center gap-1.5 cursor-pointer shadow-sm"
            >
              <span>Apply on {job.source}</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
