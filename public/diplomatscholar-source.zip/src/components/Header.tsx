import React, { useState } from 'react';
import { RefreshCw, Briefcase, GraduationCap, Smartphone, Wifi, CheckCircle2, Cloud, Download, Loader2 } from 'lucide-react';
import { UserProfile } from '../types';
import { downloadProjectArchive } from '../utils/downloadArchive';

interface HeaderProps {
  appMode: 'scholarships' | 'jobs';
  setAppMode: (mode: 'scholarships' | 'jobs') => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  profile: UserProfile;
  onRunScan: () => void;
  onOpenIPhoneModal: () => void;
  isScanning: boolean;
  totalScholarships: number;
  newScholarshipsCount: number;
  totalJobs: number;
  newJobsCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  appMode,
  setAppMode,
  activeTab,
  setActiveTab,
  profile,
  onRunScan,
  onOpenIPhoneModal,
  isScanning,
  totalScholarships,
  newScholarshipsCount,
  totalJobs,
  newJobsCount,
}) => {
  const telegramConnected = Boolean(profile.telegramChatId && profile.telegramChatId.trim().length > 0);
  const [downloadState, setDownloadState] = useState<'idle' | 'fetching' | 'success'>('idle');

  const handleDownloadZip = async () => {
    setDownloadState('fetching');
    const success = await downloadProjectArchive();
    if (success) {
      setDownloadState('success');
      setTimeout(() => setDownloadState('idle'), 4000);
    } else {
      setDownloadState('idle');
    }
  };

  // Clean, focused 4-tab navigation per mode to eliminate visual clutter
  const jobNavTabs = [
    { id: 'job_radar', label: 'Opportunities', sub: `${totalJobs} Roles` },
    { id: 'job_tracker', label: 'Pipeline & Checklists', sub: 'Status Tracker' },
    { id: 'nysc_kit', label: 'NYSC & PPA Kit', sub: 'Nov 4 Camp & Letter Builder' },
    { id: 'job_profile', label: 'Profile & Alerts', sub: telegramConnected ? 'Telegram Synced' : 'Setup Alerts' },
  ];

  const scholarshipNavTabs = [
    { id: 'radar', label: 'Scholarships', sub: `${totalScholarships} Programs` },
    { id: 'tracker', label: 'Pipeline & Deadlines', sub: 'Milestone Tracker' },
    { id: 'sop_timeline', label: 'SOP Pitch & Timeline', sub: 'Statement Builder' },
    { id: 'scholarship_profile', label: 'Profile & Alerts', sub: telegramConnected ? 'Telegram Synced' : 'Setup Alerts' },
  ];

  const currentTabs = appMode === 'jobs' ? jobNavTabs : scholarshipNavTabs;

  // Active tab resolver for grouped tabs
  const isTabActive = (tabId: string) => {
    if (activeTab === tabId) return true;
    if (tabId === 'nysc_kit' && (activeTab === 'nysc_timeline' || activeTab === 'ppa_pitch')) return true;
    if (tabId === 'job_profile' && (activeTab === 'nysc_diagnostic' || activeTab === 'telegram' || activeTab === 'training')) return true;
    if (tabId === 'sop_timeline' && (activeTab === 'timeline' || activeTab === 'sop')) return true;
    if (tabId === 'scholarship_profile' && (activeTab === 'diagnostics' || activeTab === 'telegram' || activeTab === 'training')) return true;
    return false;
  };

  return (
    <header className="border-b border-stone-200 bg-white sticky top-0 z-40 shadow-xs">
      {/* Refined Main Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        {/* Brand & Subtitle */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-base shadow-xs ${
              appMode === 'jobs' ? 'bg-emerald-900 text-emerald-300' : 'bg-stone-900 text-amber-300'
            }`}>
              {appMode === 'jobs' ? <Briefcase className="w-4 h-4 text-emerald-300" /> : <GraduationCap className="w-4 h-4 text-amber-300" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-stone-900 tracking-tight text-base">
                  DiplomatAI
                </span>
                <span className="text-stone-300">/</span>
                <span className={`text-xs font-semibold ${
                  appMode === 'jobs' ? 'text-emerald-700' : 'text-amber-800'
                }`}>
                  {appMode === 'jobs' ? 'NYSC & Lagos Placement' : 'Fully Funded Masters'}
                </span>
              </div>
              <p className="text-[11px] text-stone-500 hidden sm:block">
                {appMode === 'jobs'
                  ? 'Mainland ₦70k+ · Island · Remote US ($) · Jobberman · Indeed · Twitter · PPA Letters'
                  : 'North America & Europe · Political Science & Diplomacy · Full Tuition + Stipends'}
              </p>
            </div>
          </div>

          {/* Mobile action button */}
          <div className="flex items-center gap-1.5 md:hidden">
            <button
              onClick={onOpenIPhoneModal}
              className="px-2.5 py-1.5 text-[11px] font-semibold rounded-lg bg-emerald-50 text-emerald-900 border border-emerald-200 flex items-center gap-1"
            >
              <Cloud className="w-3 h-3 text-emerald-700" />
              <span>24/7 Cloud</span>
            </button>
            <button
              onClick={onRunScan}
              disabled={isScanning}
              className={`px-3 py-1.5 text-[11px] font-medium rounded-lg text-white flex items-center gap-1 disabled:opacity-50 ${
                appMode === 'jobs' ? 'bg-emerald-700' : 'bg-stone-900'
              }`}
            >
              <RefreshCw className={`w-3 h-3 ${isScanning ? 'animate-spin' : ''}`} />
              <span>{isScanning ? 'Scanning...' : 'Scan'}</span>
            </button>
          </div>
        </div>

        {/* Center: Mission Switcher */}
        <div className="flex items-center justify-between sm:justify-end gap-2.5">
          <div className="bg-stone-100 p-1 rounded-xl border border-stone-200/80 flex items-center text-xs">
            <button
              onClick={() => {
                setAppMode('jobs');
                setActiveTab('job_radar');
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 cursor-pointer ${
                appMode === 'jobs'
                  ? 'bg-white text-stone-900 shadow-xs font-semibold'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Briefcase className="w-3.5 h-3.5 text-emerald-600" />
              <span>Lagos Jobs & NYSC</span>
              <span className="text-[10px] text-stone-400 font-mono">({totalJobs})</span>
            </button>

            <button
              onClick={() => {
                setAppMode('scholarships');
                setActiveTab('radar');
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 cursor-pointer ${
                appMode === 'scholarships'
                  ? 'bg-white text-stone-900 shadow-xs font-semibold'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <GraduationCap className="w-3.5 h-3.5 text-amber-600" />
              <span>Scholarships</span>
              <span className="text-[10px] text-stone-400 font-mono">({totalScholarships})</span>
            </button>
          </div>

          {/* Right actions */}
          <div className="hidden md:flex items-center gap-2">
            <button
              onClick={handleDownloadZip}
              disabled={downloadState === 'fetching'}
              className="px-2.5 py-1.5 text-xs font-medium rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 border border-stone-200/80 transition-all flex items-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-60"
              title="Download verified 143 KB project ZIP archive to upload to GitHub for Render"
            >
              {downloadState === 'fetching' ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 text-stone-600 animate-spin" />
                  <span>Preparing (143 KB)...</span>
                </>
              ) : downloadState === 'success' ? (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-emerald-700 font-semibold">Saved (143 KB)!</span>
                </>
              ) : (
                <>
                  <Download className="w-3.5 h-3.5 text-stone-600" />
                  <span>Download ZIP (143 KB)</span>
                </>
              )}
            </button>

            <button
              onClick={onOpenIPhoneModal}
              className="px-3 py-1.5 text-xs font-semibold rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-950 border border-emerald-200/80 transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
              title="24/7 Cloud Hosting & 4-Hour Auto-Update Hub"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <Cloud className="w-3.5 h-3.5 text-emerald-700" />
              <span>24/7 Cloud & 4h Updates</span>
            </button>

            <button
              onClick={onRunScan}
              disabled={isScanning}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-xl text-white flex items-center gap-1.5 transition-all disabled:opacity-60 cursor-pointer shadow-xs ${
                appMode === 'jobs'
                  ? 'bg-emerald-700 hover:bg-emerald-800'
                  : 'bg-stone-900 hover:bg-stone-800'
              }`}
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
              <span>{isScanning ? 'Scanning...' : 'Live Web Scan'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Clean Secondary Navigation Tabs */}
      <div className="border-t border-stone-200/80 bg-stone-50/60 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex items-center gap-2 overflow-x-auto py-1 scrollbar-none">
          {currentTabs.map((tab) => {
            const active = isTabActive(tab.id);
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-2 px-3 text-xs font-medium rounded-lg transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
                  active
                    ? 'bg-white text-stone-900 shadow-xs border border-stone-200/80 font-semibold'
                    : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100/80'
                }`}
              >
                <span>{tab.label}</span>
                <span className="text-[10px] text-stone-400 font-normal hidden sm:inline">
                  · {tab.sub}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
